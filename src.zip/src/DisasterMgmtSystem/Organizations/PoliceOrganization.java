/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DisasterMgmtSystem.Organizations;

/**
 *
 * @author hs_sa
 */
public class PoliceOrganization extends Organization {

    public PoliceOrganization() {
        super(Organization.Type.EMERGENCY911DEPARTMENT.getValue());
    }
}
