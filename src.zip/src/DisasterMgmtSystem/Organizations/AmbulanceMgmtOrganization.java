/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DisasterMgmtSystem.Organizations;

import DisasterMgmtSystem.Ambulance.AmbulanceDirectory;

//import EcoSystem.Role.Role;
import java.util.ArrayList;
/**
 *
 * @author hs_sa
 */
public class AmbulanceMgmtOrganization 
        extends Organization 
{
    private AmbulanceDirectory ambulanceDirectoryObject;

      public AmbulanceMgmtOrganization() {
        super(Organization.Type.AMBULANCE.getValue());
         ambulanceDirectoryObject=new AmbulanceDirectory();
    }

        
     public AmbulanceDirectory getAmbulanceDirectoryObject() {
        return ambulanceDirectoryObject;
    }

    public void setAmbulanceDirectoryObject(AmbulanceDirectory ambulanceDirectoryObject) {
        this.ambulanceDirectoryObject = ambulanceDirectoryObject;
    }
    
}
